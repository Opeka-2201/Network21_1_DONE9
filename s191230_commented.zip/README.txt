Thanks again for accepting my request to send my commented code after the deadline

Monster Hunting Game : 

On ms8xx machines :
    java -jar Broker_and_Sensors 2230

On other terminal :
    java Subsriber 2230
    Variable host = "localhost" if running on same ms8xx as Broker
                    proper IP, example : "139.165.8.139" if Broker on ms801